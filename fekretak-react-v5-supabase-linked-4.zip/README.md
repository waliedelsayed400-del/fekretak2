# فكرتك مشروعك — React v5 + Supabase

## التشغيل
1. انسخ `.env.example` إلى `.env.local`.
2. ضع:
   - `VITE_SUPABASE_URL` = API URL من Supabase
   - `VITE_SUPABASE_PUBLISHABLE_KEY` = anon/public أو Publishable key
3. شغّل:
   `npm install`
   `npm run dev`

## الموجود الآن
- Login / Register / Logout
- Supabase Auth
- حفظ الاسم في user_metadata
- واجهة عربية RTL قريبة من تصميم v5
- Dashboard محمي بعد تسجيل الدخول

## ملاحظات الأمان
لا تضع `service_role` أو أي Secret key داخل React أو `.env.local` المرفوع للمستودع.
